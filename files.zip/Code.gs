/**
 * ════════════════════════════════════════════════════════════════
 * SPF FINANCE DIRECTORATE — CLOUD SYNC BACKEND
 * Google Apps Script + Google Sheets database
 * ════════════════════════════════════════════════════════════════
 *
 * SIDA LOO RAKIBO (Setup Instructions):
 * 1. Tag https://script.google.com
 * 2. Riix "New Project"
 * 3. Tirtir koodkii hore, ku copy/paste koodkan oo dhan
 * 4. Riix "Save" (Ctrl+S) — magaca project-ka u dhig "SPF Backend"
 * 5. Riix "Deploy" → "New deployment"
 * 6. Settings: Type = "Web app"
 *    - Execute as: Me
 *    - Who has access: Anyone
 * 7. Riix "Deploy" → "Authorize access" → dooro account-kaaga → "Allow"
 * 8. Koobi URL-ka la siiyo (wuxuu ku dhamaadaa /exec)
 * 9. Ku dhex dhig URL-kaas Settings > API Server URL ee system-ka HTML
 * ════════════════════════════════════════════════════════════════
 */

var SHEET_NAME = 'SPF_DATA';
var SHEET_ID_CELL = 'A1';   // header label
var SHEET_DATA_CELL = 'A2'; // actual JSON data goes here

// ── Helper: get or create the data sheet ──────────────────────
function getDataSheet() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sheet = ss.getSheetByName(SHEET_NAME);
  if (!sheet) {
    sheet = ss.insertSheet(SHEET_NAME);
    sheet.getRange('A1').setValue('SPF_JSON_DATA');
    sheet.getRange('A2').setValue('{}');
    sheet.getRange('B1').setValue('LAST_UPDATED');
    sheet.getRange('B2').setValue(new Date().toISOString());
  }
  return sheet;
}

// ── GET: return the stored data ───────────────────────────────
function doGet(e) {
  var path = (e.parameter.path || '').toLowerCase();

  // Ping/health-check endpoint
  if (path === 'ping') {
    return jsonResponse({ success: true, message: 'SPF Backend Online', time: new Date().toISOString() });
  }

  try {
    var sheet = getDataSheet();
    var raw = sheet.getRange(SHEET_DATA_CELL).getValue();
    var data = null;
    try { data = JSON.parse(raw || '{}'); } catch (err) { data = {}; }
    return jsonResponse({ success: true, data: data, updatedAt: sheet.getRange('B2').getValue() });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── POST: save new data (overwrite) ───────────────────────────
function doPost(e) {
  try {
    var body = e.postData.contents;
    var sheet = getDataSheet();

    // Validate it's proper JSON before saving
    JSON.parse(body);

    sheet.getRange(SHEET_DATA_CELL).setValue(body);
    sheet.getRange('B2').setValue(new Date().toISOString());

    return jsonResponse({ success: true, message: 'Data saved', savedAt: new Date().toISOString() });
  } catch (err) {
    return jsonResponse({ success: false, error: err.message });
  }
}

// ── Helper: JSON response with CORS headers ───────────────────
function jsonResponse(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
